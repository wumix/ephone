<?php
/**
 * Created by PhpStorm.
 * User: jaskokoyn
 * Date: 1/24/2016
 * Time: 5:08 PM
 */

require( '../../inc/db.php' );
include( '../../inc/func.inc.php' );

if(!isset($_SESSION['isAdmin']) || $_SESSION['isAdmin'] !== true){
    header("location:../");
    exit();
}

$output                 =   array('status' => 1);

if(!isReady($_POST, array('id'))){
    dj($output);
}

$id                     =   intval($_POST['id']);
$title                  =   secure($_POST['title']);
$desc                   =   secure($_POST['desc']);
$date                   =   secure($_POST['date']);
$date2                  =   strtotime($date);
$country                =   secure($_POST['country']);
$city                   =   secure($_POST['city']);
$address                =   secure($_POST['address']);
$purcase_link           =   secure($_POST['pl']);

$updateEventQuery       =   $db->prepare("UPDATE events SET title = :title, event_desc = :event_desc,
                                                            event_date_readable = :edr, event_date = :ed,
                                                            country = :country, city = :city, address = :address,
                                                            purchase_link = :pl
                                          WHERE id = :id");
$updateEventQuery->execute(array(
    ":id"               =>  $id,
    ":title"            =>  $title,
    ":event_desc"       =>  $desc,
    ":edr"              =>  $date,
    ":ed"               =>  $date2,
    ":country"          =>  $country,
    ":city"             =>  $city,
    ":address"          =>  $address,
    ":pl"               =>  $purcase_link
));
$output['status']       =   2;
dj($output);