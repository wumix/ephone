<?php
/**
 * Created by PhpStorm.
 * User: jaskokoyn
 * Date: 1/25/2016
 * Time: 12:31 PM
 */

require( '../../inc/db.php' );
include( '../../inc/func.inc.php' );

if(!isset($_SESSION['isAdmin']) || $_SESSION['isAdmin'] !== true){
    header("location:../");
    exit();
}

$output              =   array();

if(!isReady($_POST, array('pid'))){
    dj($output);
}

$pid                 =   intval($_POST['pid']);
$delQuery            =   $db->prepare("DELETE FROM pages WHERE id = :id");
$delQuery->execute(array(":id"           =>  $pid));

dj($output);