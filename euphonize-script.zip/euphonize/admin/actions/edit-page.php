<?php
/**
 * Created by PhpStorm.
 * User: jaskokoyn
 * Date: 1/25/2016
 * Time: 12:45 PM
 */

require( '../../inc/db.php' );
include( '../../inc/func.inc.php' );

if(!isset($_SESSION['isAdmin']) || $_SESSION['isAdmin'] !== true){
    header("location:../");
    exit();
}

$output                 =   array('status' => 1);

if(!isReady($_POST, array('title', 'page_content'))){
    dj($output);
}

$title                  =   secure($_POST['title']);
$slug_url               =   create_slug($title);
$page_content           =   $_POST['page_content'];

$insertGenreQuery       =   $db->prepare("UPDATE pages SET title = :t, page_content = :pc, page_slug = :ps WHERE id = :id");
$insertGenreQuery->execute(array(
    ":id"               =>  intval($_POST['id']),
    ":t"                =>  $title,
    ":pc"               =>  $page_content,
    ":ps"               =>  $slug_url
));

$output['status']       =   2;
dj($output);