<?php
/**
 * Created by PhpStorm.
 * User: jaskokoyn
 * Date: 1/24/2016
 * Time: 4:28 PM
 */

require( '../../inc/db.php' );
include( '../../inc/func.inc.php' );

if(!isset($_SESSION['isAdmin']) || $_SESSION['isAdmin'] !== true){
    header("location:../");
    exit();
}

$output                 =   array('status' => 1);

if(!isReady($_POST, array('id'))){
    dj($output);
}

$id                     =   intval($_POST['id']);
$title                  =   secure($_POST['title']);
$desc                   =   secure($_POST['desc']);
$album_type             =   secure($_POST['album_type']);
$purchase_link          =   secure($_POST['pl']);
$record_label           =   secure($_POST['rl']);
$release_date           =   secure($_POST['rd']);
$downloadable           =   intval($_POST['downloadable']);
$gid                    =   intval($_POST['gid']);

$updateTrackQuery       =   $db->prepare("UPDATE albums SET title = :title, album_desc = :album_desc, type = :t,
                                                        purchase_link = :pl, record_label = :rl,
                                                        release_date = :rd, downloadable = :dl, genre = :gid
                                      WHERE id = :id");
$updateTrackQuery->execute(array(
    ":id"               =>  $id,
    ":title"            =>  $title,
    ":album_desc"       =>  $desc,
    ":t"                =>  $album_type,
    ":pl"               =>  $purchase_link,
    ":rl"               =>  $record_label,
    ":rd"               =>  $release_date,
    ":dl"               =>  $downloadable,
    ":gid"              =>  $gid
));
$output['status']       =   2;
dj($output);