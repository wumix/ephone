<?php
/**
 * Created by PhpStorm.
 * User: jaskokoyn
 * Date: 1/10/2016
 * Time: 5:54 PM
 */

require( '../../inc/db.php' );
include( '../../inc/func.inc.php' );

if(!isset($_SESSION['isAdmin']) || $_SESSION['isAdmin'] !== true){
    header("location:../");
    exit();
}

$output             =   array('status' => 1);

if(!isReady($_POST, array('widgets'))){
    dj($output);
}

$widgets            =   json_encode($_POST['widgets']);

$updateSettingsQuery=   $db->prepare("UPDATE settings SET widgets = :w WHERE id='1'");
$updateSettingsQuery->execute(array(
    ":w"            =>  $widgets
));

$output['status']   =   2;
dj($output);