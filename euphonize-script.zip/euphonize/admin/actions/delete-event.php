<?php
/**
 * Created by PhpStorm.
 * User: jaskokoyn
 * Date: 1/24/2016
 * Time: 4:50 PM
 */

require( '../../inc/db.php' );
include( '../../inc/func.inc.php' );

if(!isset($_SESSION['isAdmin']) || $_SESSION['isAdmin'] !== true){
    header("location:../");
    exit();
}

$output             =   array();

if(!isReady($_POST, array('eid'))){
    dj($output);
}

$eid                =   intval($_POST['eid']);

$delEventQuery      =   $db->prepare("DELETE FROM events WHERE id = :id");
$delEventQuery->execute(array(":id"           =>  $eid));
dj($output);