<?php
/**
 * Created by PhpStorm.
 * User: jaskokoyn
 * Date: 1/24/2016
 * Time: 4:09 PM
 */

require( '../../inc/db.php' );
include( '../../inc/func.inc.php' );

if(!isset($_SESSION['isAdmin']) || $_SESSION['isAdmin'] !== true){
    header("location:../");
    exit();
}

$output             =   array();

if(!isReady($_POST, array('aid'))){
    dj($output);
}

$aid                =   intval($_POST['aid']);

$delTrackQuery      =   $db->prepare("DELETE FROM albums WHERE id = :id");
$delTrackQuery->execute(array(":id"           =>  $aid));
dj($output);