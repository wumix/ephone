<?php
/**
 * Created by PhpStorm.
 * User: jaskokoyn
 * Date: 1/25/2016
 * Time: 12:26 PM
 */

require( '../../inc/db.php' );
include( '../../inc/func.inc.php' );

if(!isset($_SESSION['isAdmin']) || $_SESSION['isAdmin'] !== true){
    header("location:../");
    exit();
}

$output                 =   array('status' => 1);

if(!isReady($_POST, array('title', 'page_content'))){
    dj($output);
}

$title                  =   secure($_POST['title']);
$slug_url               =   create_slug($title);
$page_content           =   $_POST['page_content'];

$insertGenreQuery       =   $db->prepare("INSERT INTO pages(title,page_content,page_slug) VALUES( :t, :pc, :ps )");
$insertGenreQuery->execute(array(
    ":t"                =>  $title,
    ":pc"               =>  $page_content,
    ":ps"               =>  $slug_url
));

$output['status']       =   2;
dj($output);